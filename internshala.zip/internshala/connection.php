<?php
//create connection variables
$host="localhost";
$user="vikram";
$pass="8989216681";
// create connection
$conn = mysqli_connect($host,$user,$pass);


?>